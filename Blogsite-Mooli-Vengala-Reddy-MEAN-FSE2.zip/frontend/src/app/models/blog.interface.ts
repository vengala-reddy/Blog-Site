export interface IBlog {
  blogName: string;
  category: string;
  article: string;
  authorName: string;
  timestamp: Date;
}

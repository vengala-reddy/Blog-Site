import { Routes } from '@angular/router';
import { BlogSearchComponent } from './blog-search/blog-search.component';

export const routes: Routes = [
    {path:'blog-search', component: BlogSearchComponent},
];
